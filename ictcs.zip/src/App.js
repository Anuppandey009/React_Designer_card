import "./styles.css";
import {Pizza} from "./Components/Pizza"

export default function App() {
  return (
    <div id="item">
  <Pizza />
    </div>
  );
}
